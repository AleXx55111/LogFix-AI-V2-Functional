from fastapi import FastAPI
from .db import get_connection

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/checkout")
def checkout(order: dict):
    conn = get_connection()
    result = conn.execute("INSERT INTO orders VALUES (...) ")
    return {"result": str(result)}
