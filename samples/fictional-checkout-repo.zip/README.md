# Checkout API
Python FastAPI checkout service. PostgreSQL stores orders. /health is used by load balancers.
